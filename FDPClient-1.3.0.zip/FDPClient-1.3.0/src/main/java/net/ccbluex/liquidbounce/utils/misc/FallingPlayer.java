/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/Project-EZ4H/FDPClient/
 */
package net.ccbluex.liquidbounce.utils.misc;

import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;

public class FallingPlayer extends MinecraftInstance {
    
    private double x;
    private double y;
    private double z;

    private double motionX;
    private double motionY;
    private double motionZ;

    private float yaw;

    private float strafe;
    private float forward;
    private float jumpMovementFactor;

    // support old codes
    public FallingPlayer(double x, double y, double z, double motionX, double motionY, double motionZ, float yaw, float strafe, float forward){
        this(x, y, z, motionX, motionY, motionZ, yaw, strafe, forward, mc.thePlayer.jumpMovementFactor);
    }

    public FallingPlayer(double x, double y, double z, double motionX, double motionY, double motionZ, float yaw, float strafe, float forward, float jumpMovementFactor) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.motionX = motionX;
        this.motionY = motionY;
        this.motionZ = motionZ;
        this.yaw = yaw;
        this.strafe = strafe;
        this.forward = forward;
        this.jumpMovementFactor = jumpMovementFactor;
    }

    private void calculateForTick() {
        strafe *= 0.98F;
        forward *= 0.98F;

        float v = strafe * strafe + forward * forward;

        if (v >= 0.0001f) {
            v = MathHelper.sqrt_float(v);

            if (v < 1.0F) {
                v = 1.0F;
            }

            v = jumpMovementFactor / v;
            strafe = strafe * v;
            forward = forward * v;
            float f1 = MathHelper.sin(yaw * (float) Math.PI / 180.0F);
            float f2 = MathHelper.cos(yaw * (float) Math.PI / 180.0F);
            this.motionX += strafe * f2 - forward * f1;
            this.motionZ += forward * f2 + strafe * f1;
        }


        motionY -= 0.08;

        motionX *= 0.91;
        motionY *= 0.9800000190734863D;
        motionY *= 0.91;
        motionZ *= 0.91;

        x += motionX;
        y += motionY;
        z += motionZ;
    }

    public BlockPos findCollision(int ticks) {
        for (int i = 0; i < ticks; i++) {
            Vec3 start = new Vec3(x, y, z);

            calculateForTick();

            Vec3 end = new Vec3(x, y, z);

            BlockPos raytracedBlock;

            float w = mc.thePlayer.width / 2F;

            if ((raytracedBlock = rayTrace(start, end)) != null) return raytracedBlock;

            if ((raytracedBlock = rayTrace(start.addVector(w, 0, w), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(-w, 0, w), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(w, 0, -w), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(-w, 0, -w), end)) != null) return raytracedBlock;

            if ((raytracedBlock = rayTrace(start.addVector(w, 0, w / 2f), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(-w, 0, w / 2f), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(w / 2f, 0, w), end)) != null) return raytracedBlock;
            if ((raytracedBlock = rayTrace(start.addVector(w / 2f, 0, -w), end)) != null) return raytracedBlock;

        }

        return null;
    }


    @Nullable
    private BlockPos rayTrace(Vec3 start, Vec3 end) {
        MovingObjectPosition result = mc.theWorld.rayTraceBlocks(start, end, true);

        if (result != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && result.sideHit == EnumFacing.UP) {
            return result.getBlockPos();
        }
        return null;
    }

}